//DEFINE STORES API REQUEST URL
//In the line below, replace the url in quotes with your 'stores' API URL from APEX
var stores_api_url = "https://d0dp28asaenqcw8-adwdemo1.adb.us-ashburn-1.oraclecloudapps.com/ords/DEVELOPER/salesAPI/stores";

//DEFINE INVENTORY FORECASTING API REQUEST URL
//In the line below, replace the url in quotes with your 'Inventory Forecasting' API URL from APEX, deleting "{store_add}" from the end of the url
//The URL should be cut off after inventoryForecastingAPI/ similar to the URL below
var inventory_forecasting_api_url = "https://d0dp28asaenqcw8-adwdemo1.adb.us-ashburn-1.oraclecloudapps.com/ords/DEVELOPER/salesAPI/product/inventoryForecastingAPI/";


//initializing global variables
var x, i, j, selElmnt, a, b, c;
var selectedStoreName;
var stores = [];
var storeNames = [];
var store_id;

function onLoad() {
    //initialize new REST API request
    var request = new XMLHttpRequest();

    //set the request parameters
    request.open("GET", stores_api_url);
    
    //send the request defined above
    request.send();

    //handle the response data
    request.onload = function () {
        var storeData = JSON.parse(this.response);

        var dropdown = document.getElementById("stores");

        //add all store options to dropdown
        for(var store in storeData.items) {
            stores.push(storeData.items[store]);
            storeNames.push(stores[store].store_address);
            var storeElement = document.createElement("option");
            storeElement.innerHTML = storeNames[store];
            storeElement.value = parseInt(store) + 1;
            dropdown.appendChild(storeElement);
        }

        console.log(stores);

        //select dropdown html element
        x = document.querySelectorAll(".custom-select");
        for (i = 0; i < x.length; i++) {
        selElmnt = x[i].getElementsByTagName("select")[0];

        //create a new div for each select element
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);

        //create div with dropdown options
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");
        for (j = 1; j < selElmnt.length; j++) {
            c = document.createElement("DIV");
            c.innerHTML = selElmnt.options[j].innerHTML;
            c.addEventListener("click", function(e) {
                //update select box when option is selected from dropdown
                var y, i, k, s, h;
                s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                h = this.parentNode.previousSibling;
                for (i = 0; i < s.length; i++) {
                if (s.options[i].innerHTML == this.innerHTML) {
                    s.selectedIndex = i;
                    h.innerHTML = this.innerHTML;
                    y = this.parentNode.getElementsByClassName("same-as-selected");
                    for (k = 0; k < y.length; k++) {
                    y[k].removeAttribute("class");
                    }
                    this.setAttribute("class", "same-as-selected");
                    break;
                }
                }
                h.click();

                //update global variables with selected option's data
                var storeName = document.getElementById("storeTitle");
                storeName.innerHTML = h.innerHTML;
                selectedStoreName = h.innerHTML;
                var selectedTable = document.getElementById("inventoryTable");
                if(selectedTable.parentNode !== null) {
                    selectedTable.parentNode.removeChild(selectedTable);
                }
            });
            
            b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function(e) {
            //close dropdown when a selection is made
            e.stopPropagation();
            closeAllSelect(this);
            this.nextSibling.classList.toggle("select-hide");
            this.classList.toggle("select-arrow-active");
            });
        }

        document.addEventListener("click", closeAllSelect);

    }
}



function closeAllSelect(elmnt) {
    //close dropdown
    var x, y, i, arrNo = [];
    x = document.getElementsByClassName("select-items");
    y = document.getElementsByClassName("select-selected");
    for (i = 0; i < y.length; i++) {
        if (elmnt == y[i]) {
        arrNo.push(i)
        } else {
        y[i].classList.remove("select-arrow-active");
        }
    }
    for (i = 0; i < x.length; i++) {
        if (arrNo.indexOf(i)) {
        x[i].classList.add("select-hide");
        }
    }
}


function addTable() {

    var storeProducts = [];

    //update store ID to selected store
    for(i=0; i<stores.length; i++) {
        if(selectedStoreName == stores[i].store_address) {
            // store_id = stores[i].id;
            store_id = selectedStoreName;
        }
    }


    //define new REST API request
    var request = new XMLHttpRequest();

    //set the request parameters
    request.open("GET", inventory_forecasting_api_url + store_id);

    //send the request defined above
    request.send();

    //handle the response data
    request.onload = function () {
        var storeProductData = JSON.parse(this.response);

        for(var product in storeProductData.items) {
            storeProducts.push(storeProductData.items[product]);
        }
        
        var productsArray = [];
        //add store's inventory to products array
        for(var product in storeProducts) {
            productsArray[product] = new Array(storeProducts[product].store_address, storeProducts[product].item_name, storeProducts[product].item_type, storeProducts[product].unitprice, storeProducts[product].currently_available, storeProducts[product].total_pred, storeProducts[product].to_be_orderd);
        }


        var tableElement = document.getElementById("inventoryTable");

        var myTableDiv = document.getElementById("container");
        if(!tableElement) {
            //create inventory table for store
            var table = document.createElement('TABLE');
            table.id = "inventoryTable"
            var tableBody = document.createElement('TBODY');
            table.border = '1';
            table.appendChild(tableBody);

            table.style.borderColor = "rgba(0,0,0,0.05)";
            table.style.borderStyle = "double";

            var heading = new Array();
            heading[0] = "Store Address";
            heading[1] = "Item Name";
            heading[2] = "Item Type";
            heading[3] = "Unit Price";
            heading[4] = "Available Quantity             (Ordered Inventory - Sales)";
            heading[5] = "Predicted Quantity";
            heading[6] = "To Be Ordered Quantity  (Predicted - Available)";
            var tr = document.createElement('TR');
            tableBody.appendChild(tr);
            for(i=0; i<heading.length;i++) {
                var th = document.createElement('TH');
                th.width = '75';
                th.appendChild(document.createTextNode(heading[i]));
                tr.appendChild(th);
            }

            for(i=0; i<productsArray.length; i++) {
                var tr = document.createElement('TR');
                for (j=0; j<productsArray[i].length; j++) {
                    var td = document.createElement('TD');
                    td.appendChild(document.createTextNode(productsArray[i][j]));
                    tr.appendChild(td);
                }
                tableBody.appendChild(tr);
            }
            myTableDiv.appendChild(table);
        }
    }
}